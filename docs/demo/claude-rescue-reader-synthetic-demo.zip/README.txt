Claude Rescue Reader synthetic demo export

Every person, organization, account, path, file, identifier, event, and number in this archive is fictional. It is safe to use for product demonstrations and tests.
